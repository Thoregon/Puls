/**
 *
 *
 * @author: Bernhard Lukassen
 * @licence: MIT
 * @see: {@link https://github.com/Thoregon}
 */

import Archetim from "./lib/archetim.mjs";

export default new Archetim();
