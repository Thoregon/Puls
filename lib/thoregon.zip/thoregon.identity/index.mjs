/**
 *
 *
 * @author: Bernhard Lukassen
 */

import Controller       from "./lib/controller.mjs";

export default new Controller();

