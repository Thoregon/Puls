/**
 *
 *
 * @author: Bernhard Lukassen
 */

import IdentityAccess from "./lib/identityaccess.mjs";

export default new IdentityAccess();

