/**
 *
 *
 * @author: Bernhard Lukassen
 */

// unused, will be completely refactored
// export { default as tru4Dctx }                from './setup.mjs';
