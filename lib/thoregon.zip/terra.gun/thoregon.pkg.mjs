export default {
    main: '',
    modules: [

    ]
}
