/**
 *
 *
 * @author: Bernhard Lukassen
 */

import GunService       from "./lib/reliant/gunservice.mjs";

export const service = new GunService();
