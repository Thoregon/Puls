/**
 *
 *
 * @author: Bernhard Lukassen
 * @licence: MIT
 * @see: {@link https://github.com/Thoregon}
 */

import MaterialLink from "./materiallink.mjs";

export default class MaterialCollectionLink extends MaterialLink {

}
