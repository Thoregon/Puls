/**
 * just a shortcut for require
 *
 * @author: blukassen
 */
