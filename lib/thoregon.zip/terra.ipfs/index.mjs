/**
 *
 *
 * @author: Bernhard Lukassen
 * @licence: MIT
 * @see: {@link https://github.com/Thoregon}
 */

import HeavyMatter from "./lib/heavymatter.mjs";

export const service = new HeavyMatter();
